# DiversionProg

Tech Stack Used:
1. HTML
2. CSS
3. JS
4. Node js
5. Express
6. Mongodb
7.Teachable machine ( free tool from google)




Instructions to Spin up the app:
1. As we are using Node js so there will be node modules which is to be installed using the command 
npm install
2.As we are using MongoDb as database so it should be present locally or on cloud.






Instructions for the student:-
1.A study table or a school bag which is fat enough to serve the purpose or any other thing in order to make their both hands visible which is only required for laptop users as desktop users with webcam can adjust their camera angle.
2.Students needs to do signup before logging in.






Types of warnings:-
1.One hand outside the screen.
2.Face outside the screen.
3.More than one person inside the screen.
4.Switching Tabs.
5.Resizing Tabs.




Things disabled:-
1.Right click.
2.Navigation buttons on resizing the tab.
3.Submit button on resizing the tab.





Future scopes:-
1.Detection of keywords like "question","answer",etc., during examination to give warning to the student based on the remaining things he/she says afterwards.
2.Better data collection like creating google forms ,drives,etc.
3.Tracking location of multiple students to avoid students giving exams in group

